
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h1>Location </h1>
			<form action="<?php echo e(route('route.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="row form-group">
					<div class="col-md-3 ">
					<label>From</label>
				</div>
				<div class="col-md-4">
					<select name="from" class="form-control">
					<option>Select From</option>
					<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($location->id); ?>"><?php echo e($location->city); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
				<div class="row form-group">
					<div class="col-md-3 ">
					<label>to</label>
				</div>
				<div class="col-md-4">
					<select name="to" class="form-control">
					<option>Select to</option>
					<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($location->id); ?>"><?php echo e($location->city); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				 

				<div class="col-md-3 ">
					<input type="submit" value="ADD" class="btn btn-dark ">
				</div>
				</div>
				
			</form>
		</div>
		<div class="col-md-12 mt-5">
			<h3>Location list</h3>
			<table class="table table-active">
				<thead>
					<th>NO.</th>
					<th>From</th>
					<th>To</th>
					<th>Action</th>
				</thead>
				<?php $i = 1 ?>
					<?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tbody>
					
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($route->locationFrom->city); ?></td>
						<td><?php echo e($route->locationTo->city); ?></td>
						<td> 
							<a href="<?php echo e(route('route.edit',$route->id)); ?>" class="btn btn-primary float-left mr-3">Edit</a>
							<form action="<?php echo e(route('route.destroy',$route->id)); ?>" method="post">
			                  <?php echo method_field('Delete'); ?>
			                  <?php echo csrf_field(); ?>
			                  <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                			</form>
                		</td>		
				
				</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
</div>	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CarTicket\resources\views/route/index.blade.php ENDPATH**/ ?>