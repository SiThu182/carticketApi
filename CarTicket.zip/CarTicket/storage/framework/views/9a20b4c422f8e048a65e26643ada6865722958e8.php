
<?php $__env->startSection('content'); ?>
	<div class="col-md-10 offset-1">
		 
		<div class="tripd">
			<div class="tripd-header">
				<h3 class="tripd-title">Trip </h3>
			</div>
			<form action="<?php echo e(route('booking.store')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				<div class="tripd-body">
				
				
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Quantity</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="quantity" class="form-control" >
						</div>
	
					</div>	
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Booking Date</label>
						</div>
						<div class="col-md-8">
							<input type="date" name="departure_time" class="form-control">
						</div>
	
					</div>
				 
				  
					<div class="row form-group">
						<div class="col-md-3 ">
						<label>Car </label>
						</div>
						<div class="col-md-4">
							<select name="car" class="form-control">
							<option>Select From</option>
							<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($car->id); ?>"><?php echo e($car->car_no); ?> <?php echo e($car->type); ?> <?php echo e($car->seat_no); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
						<label>Trip </label>
						</div>
						<div class="col-md-4">
							<select name="car" class="form-control">
							<option>Select Trip</option>
							<?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($trip->id); ?>">  <?php echo e($trip->routes->locationFrom->city); ?> to <?php echo e($trip->routes->locationTo->city); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
					 

					 
					<input type="submit" value="ADD" class="btn btn-dark">
				</div>
			</form>	
			
		</div>	
			
		

		</div>
		 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CarTicket\resources\views/booking.blade.php ENDPATH**/ ?>