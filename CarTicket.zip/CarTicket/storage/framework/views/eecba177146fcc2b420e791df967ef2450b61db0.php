
<?php $__env->startSection('content'); ?>
	<div class="col-md-10 offset-1">
		 
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">Car Edit</h3>
			</div>
			<form action="<?php echo e(route('car.update',$car->id)); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
				<div class="card-body">
				
				
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Car no</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="car_no" class="form-control" value="<?php echo e($car->car_no); ?>">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Car Type</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="type" class="form-control" value="<?php echo e($car->type); ?>">
						</div>
	
					</div>		
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Seat no</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="seat_no" class="form-control" value="<?php echo e($car->seat_no); ?>">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>New Image</label>
						</div>
						<div class="col-md-8">
							<input type="file" name="car_image" class="form-control">
						</div>
	
					</div>	
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>old Image</label>
						</div>
						<div class="col-md-8">
							<img src="<?php echo e($car->car_image); ?>" width="150" height="150">
						</div>
						<input type="hidden" name="old_image" value="<?php echo e($car->car_image); ?>">
	
					</div>	
					<input type="submit" value="ADD" class="btn btn-dark">
				</div>
			</form>	
			
		</div>	
			
		

		</div>

</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CarTicket\resources\views/car/edit.blade.php ENDPATH**/ ?>