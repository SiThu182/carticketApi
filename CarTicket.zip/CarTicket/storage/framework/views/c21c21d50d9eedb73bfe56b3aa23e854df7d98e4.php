
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h1>Location </h1>
			<form action="<?php echo e(route('route.update',$route->id)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<div class="row form-group">
					<div class="col-md-3 ">
					<label>From</label>
				</div>
				<div class="col-md-4">
					<select name="from" class="form-control">
					<option>Select From</option>
					<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($location->id); ?>"
							<?php if($location->id == $route->from): ?>
							<?php echo e('selected'); ?>

							<?php endif; ?>
							><?php echo e($location->city); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
				<div class="row form-group">
					<div class="col-md-3 ">
					<label>to</label>
				</div>
				<div class="col-md-4">
					<select name="to" class="form-control">
					<option>Select to</option>
					<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($location->id); ?>"
							<?php if($location->id == $route->to): ?>
							<?php echo e('selected'); ?>

							<?php endif; ?>
							><?php echo e($location->city); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				 

				<div class="col-md-3 ">
					<input type="submit" value="ADD" class="btn btn-dark ">
				</div>
				</div>
				
			</form>
		</div>

</div>	
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CarTicket\resources\views/route/edit.blade.php ENDPATH**/ ?>