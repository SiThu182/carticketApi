<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('location.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Location</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('car.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Car</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('route.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Route</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('trip.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Trip</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('booking.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Booking</span></a>
      </li>
      
      
    </ul>
<?php /**PATH C:\xampp\htdocs\CarTicket\resources\views/sidebar.blade.php ENDPATH**/ ?>