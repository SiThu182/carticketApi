
<?php $__env->startSection('content'); ?>
	<div class="col-md-10 offset-1">
		 
		<div class="tripd">
			<div class="tripd-header">
				<h3 class="tripd-title">Trip </h3>
			</div>
			<form action="<?php echo e(route('trip.update',$trip->id)); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
				<div class="tripd-body">
				
				
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Class</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="class_name" class="form-control" value="<?php echo e($trip->class_name); ?>">
						</div>
	
					</div>	
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Departure Time</label>
						</div>
						<div class="col-md-8">
							<input type="datetime-local" name="departure_time" class="form-control" value="<?php echo e($trip->departure_time); ?>">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Arrival Time</label>
						</div>
						<div class="col-md-8">
							<input type="datetime-local" name="arrival_time" class="form-control" value="<?php echo e($trip->arrival_time); ?>">
						</div>
	
					</div>

					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Local Price</label>
						</div>
						<div class="col-md-8">
							<input type="number" name="local_price" class="form-control" value="<?php echo e($trip->local_price); ?>">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Foregin Price $</label>
						</div>
						<div class="col-md-8">
							<input type="number" name="foregin_price" class="form-control" value="<?php echo e($trip->foregin_price); ?>">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
						<label>Car </label>
						</div>
						<div class="col-md-4">
							<select name="car" class="form-control">
							<option>Select From</option>
							<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($car->id); ?>"
									<?php if($car->id == $trip->car_id): ?>
										<?php echo e('selected'); ?>

									<?php endif; ?>									
									><?php echo e($car->car_no); ?> <?php echo e($car->type); ?> <?php echo e($car->seat_no); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>From</label>
						</div>
						<div class="col-md-4">
							<select name="route" class="form-control">
							<option>Select From</option>
							<?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($route->id); ?>"
										<?php if($route->id == $trip->route_id): ?>
										<?php echo e('selected'); ?>

									<?php endif; ?>	
									><?php echo e($route->locationFrom->city); ?>=><?php echo e($route->locationTo->city); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
				</div>

					 
					<input type="submit" value="ADD" class="btn btn-dark">
				</div>
			</form>	
			
		</div>	
			
		

		</div>
		 
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CarTicket\resources\views/trip/edit.blade.php ENDPATH**/ ?>