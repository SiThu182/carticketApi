
<?php $__env->startSection('content'); ?>
	<div class="col-md-10 offset-1">
		 
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">Car</h3>
			</div>
			<form action="<?php echo e(route('car.store')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				<div class="card-body">
				
				
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Car no</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="car_no" class="form-control">
						</div>
	
					</div>	
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Seat no</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="seat_no" class="form-control">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Image</label>
						</div>
						<div class="col-md-8">
							<input type="file" name="car_image" class="form-control">
						</div>
	
					</div>	
					<input type="submit" value="ADD" class="btn btn-dark">
				</div>
			</form>	
			
		</div>	
			
		

		</div>
		<div class="col-md-12 mt-5">
			<h3>Car list</h3>
			<table class="table table-active">
				<thead>
					<th>NO.</th>
					<th>Car No</th>
					<th>Sear No</th>
					<th>Image</th>
					<th>Action</th>
				</thead>
				<?php $i = 1 ?>
					<?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tbody>
					
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($car->car_no); ?></td>
						<td><?php echo e($car->seat_no); ?></td>
						<td><img src="<?php echo e($car->car_image); ?>" height="150" width="150"></td>
						<td> 
							<a href="<?php echo e(route('car.edit',$car->id)); ?>" class="btn btn-primary float-left mr-3">Edit </a>
							<form action="<?php echo e(route('car.destroy',$car->id)); ?>" method="post">
			                  <?php echo method_field('Delete'); ?>
			                  <?php echo csrf_field(); ?>
			                  <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                			</form>

                		</td>		
				
				</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CarTicket\resources\views/car.blade.php ENDPATH**/ ?>